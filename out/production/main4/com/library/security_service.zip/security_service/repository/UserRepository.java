package com.library.security_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<entity.User, Long> {
    entity.User findByUsername(String username);
}